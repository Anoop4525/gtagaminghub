const fs = require('fs');
const path = require('path');

// Root paths
const ROOT_DIR = path.resolve(__dirname, '..');
const DATA_DIR = path.join(ROOT_DIR, 'data');
const DIST_DIR = path.join(ROOT_DIR, 'dist');

// Load Data
const siteConfig = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'site-config.json'), 'utf8'));
const products = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'products.json'), 'utf8'));
const games = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'games.json'), 'utf8'));
const guides = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'guides.json'), 'utf8'));
const affiliateConfig = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'affiliate-links.json'), 'utf8'));
const retailers = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'retailers.json'), 'utf8'));

// SVG Icons
const ICONS = {
  logo: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="34" height="34">
    <defs>
      <linearGradient id="ggLg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#B7FF42"/>
        <stop offset="50%" stop-color="#39B8FF"/>
        <stop offset="100%" stop-color="#7A5CFF"/>
      </linearGradient>
    </defs>
    <polygon points="32,4 58,18 58,46 32,60 6,46 6,18" fill="#171E2B" stroke="#B7FF42" stroke-width="2.5" stroke-linejoin="round"/>
    <circle cx="32" cy="32" r="18" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="1.5" stroke-dasharray="3 3"/>
    <path d="M 28 20 L 19 20 C 15 20 13 23 13 27 L 13 37 C 13 41 15 44 19 44 L 29 44 C 33 44 35 41 35 37 L 35 32 L 26 32" fill="none" stroke="url(#ggLg)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 37 25 L 45 25 C 48 25 50 27 50 30 L 50 35 C 50 38 48 40 45 40 L 40 40" fill="none" stroke="#B7FF42" stroke-width="2.5" stroke-linecap="round"/>
    <circle cx="32" cy="32" r="2" fill="#B7FF42"/>
  </svg>`,
  search: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  heart: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>`,
  sun: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`,
  menu: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>`,
  close: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  arrowRight: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`,
  check: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#B7FF42" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
  shield: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#B7FF42" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
  info: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
  external: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`,
  compare: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>`
};

function renderAnnouncement() {
  if (!siteConfig.announcement?.enabled) return '';
  return `
  <div id="site-announcement" class="announcement-bar">
    <div class="container-custom flex items-center justify-between text-xs sm:text-sm">
      <div class="flex items-center gap-2 overflow-hidden">
        <span class="badge flex-shrink-0">${siteConfig.announcement.badge}</span>
        <span class="text-secondary truncate">${siteConfig.announcement.text}</span>
        <a href="${siteConfig.announcement.linkUrl}" class="text-accent-primary font-semibold hover:underline hidden sm:inline ml-1">${siteConfig.announcement.linkText} &rarr;</a>
      </div>
      <button id="dismiss-announcement" class="text-muted hover:text-primary ml-2 p-1" aria-label="Dismiss banner">
        ${ICONS.close}
      </button>
    </div>
  </div>`;
}

function renderHeader(currentPath) {
  const navHtml = siteConfig.navigation.map(nav => {
    const isHighlight = nav.highlight ? 'highlight' : '';
    const isActive = currentPath === nav.url ? 'active' : '';
    return `<a href="${nav.url}" class="nav-link ${isHighlight} ${isActive}">${nav.title}</a>`;
  }).join('');

  return `
  ${renderAnnouncement()}
  <header class="site-header">
    <div class="container-custom flex items-center justify-between py-3">
      <!-- Brand Logo -->
      <a href="/" class="flex items-center gap-3 group" aria-label="GTA Gaming Hub Homepage">
        ${ICONS.logo}
        <div>
          <span class="font-display font-bold text-lg sm:text-xl text-primary tracking-tight group-hover:text-accent-primary transition-colors">GTA GAMING HUB</span>
          <span class="hidden sm:block text-[10px] text-muted tracking-widest uppercase font-semibold">Independent Discovery</span>
        </div>
      </a>

      <!-- Desktop Navigation -->
      <nav class="hidden lg:flex items-center gap-1" aria-label="Main Navigation">
        ${navHtml}
      </nav>

      <!-- Action Controls -->
      <div class="flex items-center gap-2">
        <!-- Search Trigger -->
        <button type="button" data-open-search class="btn btn-outline btn-sm text-secondary hover:text-primary" aria-label="Search catalogue">
          ${ICONS.search}
          <span class="hidden md:inline text-xs ml-1">Search</span>
          <kbd class="hidden md:inline text-[10px] bg-surface-elevated px-1.5 py-0.5 rounded text-muted border border-subtle ml-1">Ctrl+K</kbd>
        </button>

        <!-- Wishlist -->
        <a href="/wishlist/" class="btn btn-outline btn-sm relative text-secondary hover:text-primary p-2" aria-label="View Saved Items">
          ${ICONS.heart}
          <span class="wishlist-counter hidden absolute -top-1.5 -right-1.5 bg-accent-primary text-black text-[10px] font-bold px-1.5 py-0.2 rounded-full">0</span>
        </a>

        <!-- Theme Toggle -->
        <button type="button" id="theme-toggle-btn" class="btn btn-outline btn-sm text-secondary hover:text-primary p-2" aria-label="Toggle theme">
          ${ICONS.sun}
        </button>

        <!-- Mobile Menu Hamburger -->
        <button type="button" id="mobile-menu-btn" class="lg:hidden btn btn-outline btn-sm p-2 text-primary" aria-label="Open mobile menu">
          ${ICONS.menu}
        </button>
      </div>
    </div>
  </header>

  <!-- Mobile Drawer -->
  <div id="mobile-drawer" class="fixed inset-0 z-50 hidden" role="dialog" aria-modal="true" aria-label="Mobile Navigation">
    <div id="mobile-backdrop" class="fixed inset-0 bg-black/70 backdrop-blur-sm"></div>
    <div class="fixed top-0 right-0 bottom-0 w-full max-w-xs bg-surface border-l border-subtle p-6 flex flex-col justify-between overflow-y-auto">
      <div>
        <div class="flex items-center justify-between pb-4 border-b border-subtle mb-6">
          <div class="flex items-center gap-2">
            ${ICONS.logo}
            <span class="font-display font-bold text-primary">GTA Gaming Hub</span>
          </div>
          <button id="mobile-drawer-close" class="btn btn-outline btn-sm p-1" aria-label="Close menu">${ICONS.close}</button>
        </div>
        <nav class="flex flex-col gap-2">
          ${siteConfig.navigation.map(nav => `
            <a href="${nav.url}" class="nav-link py-3 text-base ${nav.highlight ? 'text-accent-primary font-bold' : ''}">${nav.title}</a>
          `).join('')}
          <a href="/deals/" class="nav-link py-3 text-base">Deals & Offers</a>
          <a href="/wishlist/" class="nav-link py-3 text-base">Saved Wishlist</a>
          <a href="/compare/" class="nav-link py-3 text-base">Compare Editions</a>
        </nav>
      </div>
      <div class="pt-6 border-t border-subtle text-xs text-muted">
        <p class="mb-2">Your Independent GTA Discovery Hub</p>
        <p>&copy; 2026 GTA Gaming Hub.</p>
      </div>
    </div>
  </div>`;
}

function renderFooter() {
  return `
  <footer class="bg-secondary border-t border-subtle mt-20 pt-16 pb-12">
    <div class="container-custom">
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
        <!-- Col 1: Brand Info -->
        <div class="lg:col-span-2">
          <div class="flex items-center gap-3 mb-4">
            ${ICONS.logo}
            <span class="font-display font-bold text-xl text-primary">GTA GAMING HUB</span>
          </div>
          <p class="text-sm text-secondary leading-relaxed mb-4 max-w-sm">
            ${siteConfig.description}
          </p>
          <div class="flex items-center gap-2 text-xs text-muted mb-4">
            <span class="badge">Independent</span>
            <span>Fact-checked product catalog</span>
          </div>
        </div>

        <!-- Col 2: GTA 6 -->
        <div>
          <h4 class="text-sm font-semibold uppercase tracking-wider text-primary mb-4">GTA 6 Hub</h4>
          <ul class="space-y-2 text-sm text-secondary">
            <li><a href="/gta-6/" class="hover:text-accent-primary transition-colors">GTA 6 Overview</a></li>
            <li><a href="/gta-6/editions/" class="hover:text-accent-primary transition-colors">Confirmed Editions</a></li>
            <li><a href="/gta-6/ps5/" class="hover:text-accent-primary transition-colors">PS5 Experience</a></li>
            <li><a href="/gta-6/xbox/" class="hover:text-accent-primary transition-colors">Xbox Series X|S</a></li>
            <li><a href="/gta-6/price/" class="hover:text-accent-primary transition-colors">Price & Variants</a></li>
            <li><a href="/gta-6/buy/" class="hover:text-accent-primary transition-colors">Buying Options</a></li>
          </ul>
        </div>

        <!-- Col 3: Franchise & Store -->
        <div>
          <h4 class="text-sm font-semibold uppercase tracking-wider text-primary mb-4">Catalogue</h4>
          <ul class="space-y-2 text-sm text-secondary">
            <li><a href="/games/" class="hover:text-accent-primary transition-colors">All GTA Games</a></li>
            <li><a href="/games/gta-5/" class="hover:text-accent-primary transition-colors">GTA V & Online</a></li>
            <li><a href="/games/gta-4/" class="hover:text-accent-primary transition-colors">GTA IV Complete</a></li>
            <li><a href="/games/gta-trilogy/" class="hover:text-accent-primary transition-colors">Definitive Trilogy</a></li>
            <li><a href="/merchandise/" class="hover:text-accent-primary transition-colors">Official Merchandise</a></li>
            <li><a href="/accessories/" class="hover:text-accent-primary transition-colors">Gaming Accessories</a></li>
            <li><a href="/deals/" class="hover:text-accent-primary transition-colors">Retailer Deals</a></li>
          </ul>
        </div>

        <!-- Col 4: Guides & Legal -->
        <div>
          <h4 class="text-sm font-semibold uppercase tracking-wider text-primary mb-4">Guides & Legal</h4>
          <ul class="space-y-2 text-sm text-secondary">
            <li><a href="/guides/" class="hover:text-accent-primary transition-colors">Buyer Guides</a></li>
            <li><a href="/guides/gta-games-in-order/" class="hover:text-accent-primary transition-colors">Games in Order</a></li>
            <li><a href="/guides/gta-6-edition-comparison/" class="hover:text-accent-primary transition-colors">Editions Guide</a></li>
            <li><a href="/compare/" class="hover:text-accent-primary transition-colors">Compare Matrix</a></li>
            <li><a href="/affiliate-disclosure/" class="hover:text-accent-primary transition-colors">Affiliate Disclosure</a></li>
            <li><a href="/editorial-policy/" class="hover:text-accent-primary transition-colors">Editorial Policy</a></li>
            <li><a href="/privacy-policy/" class="hover:text-accent-primary transition-colors">Privacy Policy</a></li>
            <li><a href="/cookie-policy/" class="hover:text-accent-primary transition-colors">Cookie Policy</a></li>
            <li><a href="/terms/" class="hover:text-accent-primary transition-colors">Terms of Service</a></li>
            <li><a href="/about/" class="hover:text-accent-primary transition-colors">About Us</a></li>
            <li><a href="/contact/" class="hover:text-accent-primary transition-colors">Contact</a></li>
          </ul>
        </div>
      </div>

      <!-- Legal Disclaimers Box -->
      <div class="bg-surface p-6 rounded-xl border border-subtle text-xs text-muted space-y-3">
        <div class="flex items-start gap-2">
          <span class="text-accent-primary flex-shrink-0 mt-0.5">${ICONS.shield}</span>
          <p><strong class="text-primary">Trademark & Brand Independence:</strong> ${siteConfig.independenceDisclaimer}</p>
        </div>
        <div class="flex items-start gap-2">
          <span class="text-accent-primary flex-shrink-0 mt-0.5">${ICONS.info}</span>
          <p><strong class="text-primary">Affiliate Transparency:</strong> ${siteConfig.affiliateNotice}</p>
        </div>
      </div>

      <!-- Bottom Bar -->
      <div class="flex flex-col sm:flex-row items-center justify-between text-xs text-muted pt-8 mt-8 border-t border-subtle gap-4">
        <p>&copy; 2026 GTA Gaming Hub. All rights reserved.</p>
        <div class="flex items-center gap-4">
          <a href="/sitemap.xml" class="hover:underline">XML Sitemap</a>
          <a href="/affiliate-disclosure/" class="hover:underline">Affiliate Notice</a>
          <a href="/admin/" class="hover:underline text-muted/60">Owner Dashboard</a>
        </div>
      </div>
    </div>
  </footer>

  <!-- Search Modal -->
  <div id="search-modal" class="modal-overlay hidden" role="dialog" aria-modal="true" aria-label="Search">
    <div id="search-modal-backdrop" class="absolute inset-0"></div>
    <div class="modal-content relative z-10">
      <div class="p-4 border-b border-subtle flex items-center gap-3">
        ${ICONS.search}
        <input type="text" id="search-input" placeholder="Search GTA 6 editions, games, merch, or accessories..." class="bg-transparent border-none text-primary w-full focus:outline-none text-sm sm:text-base" autocomplete="off" />
        <button id="search-modal-close" class="btn btn-outline btn-sm p-1.5" aria-label="Close search">${ICONS.close}</button>
      </div>
      <div id="search-results" class="p-4 overflow-y-auto max-h-[60vh]"></div>
    </div>
  </div>

  <!-- Cookie Consent Banner -->
  <div id="cookie-consent-banner" class="fixed bottom-4 left-4 right-4 md:left-8 md:max-w-lg bg-surface border border-active p-5 rounded-xl shadow-2xl z-50 hidden">
    <div class="flex items-start gap-3 mb-3">
      <span class="text-accent-primary mt-0.5">${ICONS.shield}</span>
      <div>
        <h4 class="text-sm font-bold text-primary mb-1">Privacy & Cookie Preferences</h4>
        <p class="text-xs text-secondary leading-relaxed">
          We use strictly necessary and analytics cookies to optimize site navigation and measure outbound affiliate referrals without collecting personal identification.
        </p>
      </div>
    </div>
    <div class="flex items-center justify-end gap-2 text-xs">
      <button id="cookie-necessary-only" class="btn btn-outline btn-sm text-xs">Essential Only</button>
      <button id="cookie-accept-all" class="btn btn-primary btn-sm text-xs">Accept All</button>
    </div>
  </div>

  <!-- Toast Notification Container -->
  <div id="toast-container"></div>
  `;
}

function renderHtmlDocument({ title, description, canonicalPath, schemaJson, content }) {
  const fullCanonicalUrl = `${siteConfig.baseUrl}${canonicalPath}`;
  const ogImageUrl = `${siteConfig.baseUrl}/favicon.svg`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title} | ${siteConfig.siteName}</title>
  <meta name="description" content="${description}">
  <link rel="canonical" href="${fullCanonicalUrl}">
  <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">

  <!-- Open Graph / Facebook -->
  <meta property="og:type" content="website">
  <meta property="og:url" content="${fullCanonicalUrl}">
  <meta property="og:title" content="${title} | ${siteConfig.siteName}">
  <meta property="og:description" content="${description}">
  <meta property="og:site_name" content="${siteConfig.siteName}">
  <meta property="og:image" content="${ogImageUrl}">

  <!-- Twitter / X -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:url" content="${fullCanonicalUrl}">
  <meta name="twitter:title" content="${title}">
  <meta name="twitter:description" content="${description}">
  <meta name="twitter:image" content="${ogImageUrl}">

  <!-- Favicon -->
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">

  <!-- Compiled Design System Stylesheet -->
  <link rel="stylesheet" href="/src/css/main.css">

  <!-- Structured Data JSON-LD -->
  <script type="application/ld+json">
  ${JSON.stringify(schemaJson || {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": siteConfig.siteName,
    "url": siteConfig.baseUrl,
    "description": siteConfig.description,
    "potentialAction": {
      "@type": "SearchAction",
      "target": `${siteConfig.baseUrl}/search/?q={search_term_string}`,
      "query-input": "required name=search_term_string"
    }
  })}
  </script>

  <!-- Early Theme Setter to prevent FOUC -->
  <script>
    (function() {
      const saved = localStorage.getItem('gtagaminghub_theme');
      if (saved === 'light') document.documentElement.classList.add('light');
    })();
  </script>
</head>
<body class="bg-primary text-primary min-h-screen flex flex-col">
  ${renderHeader(canonicalPath)}

  <main class="flex-1">
    ${content}
  </main>

  ${renderFooter()}

  <!-- Modern Vanilla JS Core Modules -->
  <script src="/src/js/toast.js"></script>
  <script src="/src/js/analytics.js"></script>
  <script src="/src/js/theme.js"></script>
  <script src="/src/js/navigation.js"></script>
  <script src="/src/js/search.js"></script>
  <script src="/src/js/wishlist.js"></script>
  <script src="/src/js/compare.js"></script>
  <script src="/src/js/affiliate.js"></script>
  <script src="/src/js/consent.js"></script>
  <script src="/src/js/filters.js"></script>
</body>
</html>`;
}

// Module Exports
module.exports = {
  siteConfig,
  products,
  games,
  guides,
  affiliateConfig,
  retailers,
  ICONS,
  renderHtmlDocument
};
